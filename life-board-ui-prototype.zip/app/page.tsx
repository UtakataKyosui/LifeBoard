'use client'

import { useMemo, useState } from 'react'
import { Bot, CalendarDays, Check, ChevronLeft, ChevronRight, Clock3, ListChecks, Moon, Plus, Repeat2, Send, Settings2, Sparkles, Sun, X } from 'lucide-react'
import { Calendar } from '@/components/ui/calendar'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import type { DayPickerSingleProps } from 'react-day-picker'

 type Task = {
  id: number
  title: string
  detail?: string
  time?: string
  recurring?: string
  days?: number[]
  done: boolean
  section: 'today' | 'upcoming'
}

const initialTasks: Task[] = [
  { id: 1, title: '朝のストレッチ', detail: 'からだをゆっくり目覚めさせる', time: '07:00', recurring: '毎日', done: true, section: 'today' },
  { id: 2, title: '食器を片付ける', time: '08:30', recurring: '毎日', done: false, section: 'today' },
  { id: 3, title: 'ゴミを出す', detail: '燃えるゴミ', time: '09:00', recurring: '毎週 火・金', days: [2, 5], done: false, section: 'today' },
  { id: 4, title: '植物に水をあげる', time: '18:00', recurring: '毎週 火・土', done: false, section: 'today' },
  { id: 5, title: '冷蔵庫の整理', time: '土曜日', recurring: '毎週 土', done: false, section: 'upcoming' },
  { id: 6, title: 'シーツを洗う', time: '日曜日', recurring: '毎週 日', done: false, section: 'upcoming' },
]

const weekDays = [
  { label: '月', date: '12', count: 2 }, { label: '火', date: '13', count: 4, active: true },
  { label: '水', date: '14', count: 2 }, { label: '木', date: '15', count: 1 },
  { label: '金', date: '16', count: 3 }, { label: '土', date: '17', count: 3 }, { label: '日', date: '18', count: 2 },
]

export default function Home() {
  const [screen, setScreen] = useState<'home' | 'week' | 'editor'>('home')
  const [tasks, setTasks] = useState(initialTasks)
  const [dark, setDark] = useState(false)
  const [selectedDay, setSelectedDay] = useState('火')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [repeat, setRepeat] = useState('毎週')
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date(2026, 9, 13))
  const [agentOpen, setAgentOpen] = useState(false)
  const [agentInput, setAgentInput] = useState('')
  const [agentMessages, setAgentMessages] = useState([
    { role: 'agent', text: 'こんにちは。やりたいことを教えてください。必要なものと、次にすることを整理します。' },
  ])

  const completed = useMemo(() => tasks.filter((task) => task.section === 'today' && task.done).length, [tasks])
  const toggleTask = (id: number) => setTasks((current) => current.map((task) => task.id === id ? { ...task, done: !task.done } : task))
  const saveTask = () => {
    if (!title.trim()) return
    setTasks((current) => [{ id: Date.now(), title, detail: description, time: '予定', recurring: repeat, done: false, section: 'today' }, ...current])
    setTitle(''); setDescription(''); setScreen('home')
  }

  const openAgent = (prompt?: string) => {
    setAgentOpen(true)
    if (prompt) {
      setAgentInput(prompt)
    }
  }

  const askAgent = () => {
    const prompt = agentInput.trim()
    if (!prompt) return
    setAgentMessages((current) => [...current, { role: 'user', text: prompt }, { role: 'agent', text: `「${prompt}」ですね。まず目的を小さく分け、必要なものを確認してから、今日できる最初の一歩を決めましょう。必要な道具をそろえたら、15分だけ試してみるのがおすすめです。` }])
    setAgentInput('')
  }

  return (
    <div className={cn('min-h-screen bg-background text-foreground transition-colors', dark && 'dark')}>
      <div className="mx-auto flex min-h-screen max-w-[1500px] flex-col px-5 py-5 sm:px-8 lg:px-12 lg:py-8">
        <header className="flex items-center justify-between gap-4 pb-7">
          <button onClick={() => setScreen('home')} className="flex items-center gap-3 text-left" aria-label="ホームに戻る">
            <span className="grid size-11 place-items-center rounded-[14px] bg-primary text-primary-foreground shadow-sm"><ListChecks /></span>
            <span><span className="block text-[11px] font-semibold uppercase tracking-[0.26em] text-muted-foreground">HOUSEHOLD BOARD</span><span className="text-xl font-semibold tracking-tight">LifeBoard</span></span>
          </button>
          <nav className="flex items-center gap-2" aria-label="メインナビゲーション">
            <Button variant={screen === 'home' ? 'secondary' : 'ghost'} size="lg" onClick={() => setScreen('home')} className="rounded-xl px-4">今日</Button>
            <Button variant={screen === 'week' ? 'secondary' : 'ghost'} size="lg" onClick={() => setScreen('week')} className="rounded-xl px-4">週間</Button>
            <Button variant="ghost" size="icon" className="ml-1 size-11 rounded-xl" onClick={() => setDark(!dark)} aria-label="テーマを切り替える">{dark ? <Sun /> : <Moon />}</Button>
          </nav>
        </header>

        {screen === 'editor' ? <Editor title={title} setTitle={setTitle} description={description} setDescription={setDescription} repeat={repeat} setRepeat={setRepeat} selectedDate={selectedDate} setSelectedDate={setSelectedDate} onSave={saveTask} onCancel={() => setScreen('home')} /> : screen === 'week' ? <Weekly selectedDay={selectedDay} setSelectedDay={setSelectedDay} onBack={() => setScreen('home')} /> : (
          <main className="flex flex-1 flex-col gap-6">
            <section className="grid gap-5 rounded-[28px] border border-border/70 bg-card p-6 shadow-sm lg:grid-cols-[1fr_auto] lg:items-end lg:p-8">
              <div><p className="mb-3 text-sm font-medium text-muted-foreground">2026年10月13日 · 火曜日</p><div className="flex flex-wrap items-end gap-x-5 gap-y-2"><time className="text-6xl font-semibold tracking-[-0.07em] sm:text-8xl">08:42</time><span className="mb-2 rounded-full bg-accent px-3 py-1.5 text-sm font-medium text-accent-foreground">おはようございます</span></div><p className="mt-3 text-muted-foreground">今日も、できることからひとつずつ。</p></div>
              <div className="flex items-center gap-5 lg:pb-1"><div><p className="text-sm text-muted-foreground">今日の進み具合</p><p className="mt-1 text-3xl font-semibold">{completed}<span className="text-lg text-muted-foreground"> / {tasks.filter((t) => t.section === 'today').length}</span></p></div><div className="h-14 w-px bg-border" /><Button size="lg" onClick={() => setScreen('editor')} className="h-14 rounded-2xl px-5"><Plus data-icon="inline-start" />タスクを追加</Button></div>
            </section>
            <div className="grid flex-1 gap-6 lg:grid-cols-[1.3fr_0.7fr]">
              <section className="rounded-[28px] border border-border/70 bg-card p-6 shadow-sm sm:p-8"><div className="mb-6 flex items-center justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">TODAY</p><h1 className="mt-1 text-2xl font-semibold">今日のタスク</h1></div><span className="rounded-full bg-muted px-3 py-1.5 text-sm text-muted-foreground">{completed}件 完了</span></div><div className="flex flex-col gap-3">{tasks.filter((task) => task.section === 'today').map((task) => <TaskRow key={task.id} task={task} onToggle={() => toggleTask(task.id)} onAsk={() => openAgent(`「${task.title}」をするために、必要なものと手順を整理したい`)} />)}</div></section>
              <div className="flex flex-col gap-6"><section className="rounded-[28px] border border-border/70 bg-card p-6 shadow-sm sm:p-8"><div className="mb-5 flex items-center justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">UP NEXT</p><h2 className="mt-1 text-xl font-semibold">これから</h2></div><Clock3 className="text-muted-foreground" /></div><div className="flex flex-col gap-1">{tasks.filter((task) => task.section === 'upcoming').map((task) => <TaskRow compact key={task.id} task={task} onToggle={() => toggleTask(task.id)} />)}</div></section><section className="rounded-[28px] bg-primary p-6 text-primary-foreground shadow-sm sm:p-8"><div className="flex items-start justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.2em] opacity-60">ROUTINES</p><h2 className="mt-1 text-xl font-semibold">いつもの習慣</h2></div><Repeat2 className="opacity-70" /></div><div className="mt-6 grid grid-cols-2 gap-3"><div className="rounded-2xl bg-primary-foreground/10 p-4"><p className="text-2xl font-semibold">3</p><p className="mt-1 text-sm opacity-70">継続中</p></div><div className="rounded-2xl bg-primary-foreground/10 p-4"><p className="text-2xl font-semibold">86%</p><p className="mt-1 text-sm opacity-70">今週の達成率</p></div></div></section></div>
            </div>
            <section className="rounded-[28px] border border-border/70 bg-card p-6 shadow-sm sm:p-8" aria-labelledby="agent-heading">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="flex items-start gap-3"><span className="grid size-11 place-items-center rounded-2xl bg-accent text-accent-foreground"><Sparkles /></span><div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">MASTRA AGENT</p><h2 id="agent-heading" className="mt-1 text-xl font-semibold">やりたいことを、次の一歩に</h2><p className="mt-1 text-sm text-muted-foreground">必要なものと手順を一緒に整理します。</p></div></div>
                <Button variant={agentOpen ? 'secondary' : 'outline'} onClick={() => setAgentOpen(!agentOpen)} className="rounded-xl"><Bot data-icon="inline-start" />{agentOpen ? '閉じる' : '相談する'}</Button>
              </div>
              {agentOpen && <div className="mt-6 grid gap-5 lg:grid-cols-[1fr_280px]">
                <div className="flex min-h-52 flex-col rounded-2xl bg-muted/45 p-4"><div className="flex flex-1 flex-col gap-3 overflow-auto">{agentMessages.map((message, index) => <div key={`${message.role}-${index}`} className={cn('flex items-start gap-2 text-sm', message.role === 'user' && 'justify-end')}><span className={cn('max-w-[85%] rounded-2xl px-4 py-3', message.role === 'agent' ? 'bg-background text-foreground' : 'bg-primary text-primary-foreground')}>{message.text}</span></div>)}</div><div className="mt-4 flex gap-2"><input value={agentInput} onChange={(event) => setAgentInput(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.nativeEvent.isComposing && event.keyCode !== 229) askAgent() }} placeholder="例：週末に部屋を整えたい" aria-label="Mastra Agentへの相談内容" className="min-w-0 flex-1 rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none ring-ring focus:ring-2" /><Button onClick={askAgent} size="icon" className="size-11 rounded-xl" aria-label="相談を送信"><Send /></Button></div></div>
                <div className="rounded-2xl border border-border/70 p-4"><p className="text-sm font-medium">相談の進め方</p><ol className="mt-3 flex flex-col gap-3 text-sm text-muted-foreground"><li><span className="mr-2 font-semibold text-foreground">01</span>目的を確認</li><li><span className="mr-2 font-semibold text-foreground">02</span>必要なものを整理</li><li><span className="mr-2 font-semibold text-foreground">03</span>今日の一歩を提案</li></ol></div>
              </div>}
            </section>
          </main>
        )}
        <footer className="flex items-center justify-between pt-7 text-xs text-muted-foreground"><span>暮らしを、少し軽やかに。</span><button className="flex items-center gap-2 rounded-lg px-2 py-1 hover:bg-muted" aria-label="設定"><Settings2 /> 設定</button></footer>
      </div>
    </div>
  )
}

function TaskRow({ task, onToggle, onAsk, compact = false }: { task: Task; onToggle: () => void; onAsk?: () => void; compact?: boolean }) {
  return <div className={cn('group flex items-center gap-4 rounded-2xl border border-transparent bg-muted/45 px-4 py-4 transition-colors hover:border-border hover:bg-muted', compact && 'px-3 py-3')}><button onClick={onToggle} aria-label={`${task.title}を${task.done ? '未完了に戻す' : '完了にする'}`} className={cn('grid size-9 shrink-0 place-items-center rounded-xl border-2 transition-all', task.done ? 'border-primary bg-primary text-primary-foreground' : 'border-muted-foreground/30 bg-background hover:border-primary')}>{task.done && <Check />}</button><div className="min-w-0 flex-1"><p className={cn('font-medium', task.done && 'text-muted-foreground line-through')}>{task.title}</p>{task.detail && <p className="mt-0.5 truncate text-sm text-muted-foreground">{task.detail}</p>}<div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground"><span>{task.time}</span>{task.recurring && <><span>·</span><span>{task.recurring}</span></>}</div></div>{onAsk && <Button variant="ghost" size="icon" onClick={onAsk} className="size-10 shrink-0 rounded-xl text-muted-foreground hover:text-foreground" aria-label={`${task.title}について相談する`}><Bot /></Button>}{!compact && <ChevronRight className="text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />}</div>
}

function Editor({ title, setTitle, description, setDescription, repeat, setRepeat, selectedDate, setSelectedDate, onSave, onCancel }: any) {
  return <main className="mx-auto w-full max-w-4xl flex-1"><div className="mb-6 flex items-center justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">NEW TASK</p><h1 className="mt-1 text-3xl font-semibold">タスクを追加</h1></div><Button variant="ghost" size="icon" onClick={onCancel} className="size-12 rounded-xl"><X /></Button></div><div className="grid gap-6 lg:grid-cols-[1fr_340px]"><section className="rounded-[28px] border border-border/70 bg-card p-6 shadow-sm sm:p-8"><label className="text-sm font-medium" htmlFor="task-title">タスク名</label><input id="task-title" autoFocus value={title} onChange={(e) => setTitle(e.target.value)} placeholder="例：玄関を掃除する" className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-3.5 text-lg outline-none ring-ring placeholder:text-muted-foreground focus:ring-2" /><label className="mt-6 block text-sm font-medium" htmlFor="description">メモ <span className="font-normal text-muted-foreground">（任意）</span></label><textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="補足があれば入力してください" rows={4} className="mt-2 w-full resize-none rounded-xl border border-input bg-background px-4 py-3 outline-none ring-ring placeholder:text-muted-foreground focus:ring-2" /><div className="mt-7"><p className="mb-3 text-sm font-medium">繰り返し</p><div className="grid grid-cols-3 gap-2">{['一度だけ', '毎週', '隔週'].map((item) => <button key={item} onClick={() => setRepeat(item)} className={cn('rounded-xl border px-3 py-3 text-sm transition-colors', repeat === item ? 'border-primary bg-primary text-primary-foreground' : 'border-input hover:bg-muted')}>{item}</button>)}</div></div><div className="mt-7"><p className="mb-3 text-sm font-medium">曜日</p><div className="flex gap-2">{['月','火','水','木','金','土','日'].map((day) => <button key={day} className={cn('grid size-10 place-items-center rounded-full border text-sm', day === '火' ? 'border-primary bg-primary text-primary-foreground' : 'border-input hover:bg-muted')}>{day}</button>)}</div></div><div className="mt-8 flex justify-end gap-3"><Button variant="ghost" size="lg" onClick={onCancel}>キャンセル</Button><Button size="lg" onClick={onSave} disabled={!title.trim()}>保存する</Button></div></section><section className="rounded-[28px] border border-border/70 bg-card p-5 shadow-sm"><div className="mb-2 flex items-center gap-2 px-2"><CalendarDays className="text-muted-foreground" /><h2 className="font-semibold">開始日</h2></div><Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} month={new Date(2026, 9, 1)} className="w-full" /></section></div></main>
}

function Weekly({ selectedDay, setSelectedDay, onBack }: { selectedDay: string; setSelectedDay: (day: string) => void; onBack: () => void }) {
  return <main className="flex-1"><div className="mb-6 flex items-end justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">WEEKLY VIEW</p><h1 className="mt-1 text-3xl font-semibold">今週の予定</h1></div><div className="flex items-center gap-2"><Button variant="outline" size="icon" className="size-11 rounded-xl" aria-label="前の週"><ChevronLeft /></Button><span className="px-2 text-sm font-medium">10月12日 — 18日</span><Button variant="outline" size="icon" className="size-11 rounded-xl" aria-label="次の週"><ChevronRight /></Button></div></div><div className="grid grid-cols-4 gap-3 sm:grid-cols-7">{weekDays.map((day) => <button key={day.label} onClick={() => setSelectedDay(day.label)} className={cn('rounded-2xl border p-3 text-left transition-all sm:p-4', selectedDay === day.label ? 'border-primary bg-primary text-primary-foreground shadow-sm' : 'border-border/70 bg-card hover:bg-muted')}><span className="text-sm opacity-70">{day.label}</span><strong className="mt-2 block text-2xl">{day.date}</strong><span className={cn('mt-4 block text-xs', selectedDay === day.label ? 'opacity-70' : 'text-muted-foreground')}>{day.count}件</span></button>)}</div><section className="mt-6 rounded-[28px] border border-border/70 bg-card p-6 shadow-sm sm:p-8"><div className="flex items-center justify-between"><div><p className="text-sm text-muted-foreground">10月{weekDays.find((d) => d.label === selectedDay)?.date}日 · {selectedDay}曜日</p><h2 className="mt-1 text-2xl font-semibold">{selectedDay}曜日のタスク</h2></div><CalendarDays className="text-muted-foreground" /></div><div className="mt-6 grid gap-3 md:grid-cols-2"><div className="rounded-2xl bg-muted/50 p-5"><p className="font-medium">朝のストレッチ</p><p className="mt-2 text-sm text-muted-foreground">毎日 · 07:00</p></div><div className="rounded-2xl bg-muted/50 p-5"><p className="font-medium">ゴミを出す</p><p className="mt-2 text-sm text-muted-foreground">毎週 火・金 · 09:00</p></div></div><Button variant="outline" size="lg" className="mt-6 rounded-xl" onClick={onBack}>今日のボードに戻る</Button></section></main>
}
